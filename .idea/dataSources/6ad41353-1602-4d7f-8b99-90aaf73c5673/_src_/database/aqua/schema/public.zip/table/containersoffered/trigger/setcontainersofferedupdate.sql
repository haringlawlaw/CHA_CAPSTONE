CREATE TRIGGER setcontainersofferedupdate
BEFORE UPDATE ON containersoffered
FOR EACH ROW EXECUTE PROCEDURE setupdateoncolumn()