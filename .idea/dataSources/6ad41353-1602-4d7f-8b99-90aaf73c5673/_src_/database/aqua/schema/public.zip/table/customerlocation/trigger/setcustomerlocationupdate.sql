CREATE TRIGGER setcustomerlocationupdate
BEFORE UPDATE ON customerlocation
FOR EACH ROW EXECUTE PROCEDURE setupdateoncolumn()