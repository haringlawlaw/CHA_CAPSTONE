CREATE TRIGGER setshoplocationupdate
BEFORE UPDATE ON shoplocation
FOR EACH ROW EXECUTE PROCEDURE setupdateoncolumn()