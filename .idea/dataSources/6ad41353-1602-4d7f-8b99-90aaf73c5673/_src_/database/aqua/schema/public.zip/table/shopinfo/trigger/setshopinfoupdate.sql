CREATE TRIGGER setshopinfoupdate
BEFORE UPDATE ON shopinfo
FOR EACH ROW EXECUTE PROCEDURE setupdateoncolumn()