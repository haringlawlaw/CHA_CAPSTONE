CREATE TRIGGER setordercontainersupdate
BEFORE UPDATE ON ordercontainers
FOR EACH ROW EXECUTE PROCEDURE setupdateoncolumn()