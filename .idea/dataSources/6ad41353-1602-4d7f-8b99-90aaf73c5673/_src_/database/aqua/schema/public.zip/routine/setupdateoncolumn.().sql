CREATE FUNCTION setupdateoncolumn () RETURNS trigger
	LANGUAGE plpgsql
AS $$
BEGIN
   NEW.updatedOn = now(); 
   RETURN NEW;
END;
$$
