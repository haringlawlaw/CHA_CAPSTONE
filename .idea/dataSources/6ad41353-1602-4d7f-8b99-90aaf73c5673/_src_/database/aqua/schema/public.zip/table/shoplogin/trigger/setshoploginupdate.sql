CREATE TRIGGER setshoploginupdate
BEFORE UPDATE ON shoplogin
FOR EACH ROW EXECUTE PROCEDURE setupdateoncolumn()