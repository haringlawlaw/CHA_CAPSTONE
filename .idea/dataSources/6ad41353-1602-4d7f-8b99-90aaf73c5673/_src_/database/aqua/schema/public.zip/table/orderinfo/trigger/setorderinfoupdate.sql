CREATE TRIGGER setorderinfoupdate
BEFORE UPDATE ON orderinfo
FOR EACH ROW EXECUTE PROCEDURE setupdateoncolumn()