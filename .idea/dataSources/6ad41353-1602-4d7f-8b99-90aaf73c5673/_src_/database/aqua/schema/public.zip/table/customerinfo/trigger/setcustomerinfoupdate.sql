CREATE TRIGGER setcustomerinfoupdate
BEFORE UPDATE ON customerinfo
FOR EACH ROW EXECUTE PROCEDURE setupdateoncolumn()