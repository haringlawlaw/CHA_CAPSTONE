CREATE TRIGGER setwatertypesofferedupdate
BEFORE UPDATE ON watertypesoffered
FOR EACH ROW EXECUTE PROCEDURE setupdateoncolumn()